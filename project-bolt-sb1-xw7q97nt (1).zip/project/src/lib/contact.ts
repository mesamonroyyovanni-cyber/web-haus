const PHONE_NUMBER = '+34613665384';
const WHATSAPP_NUMBER = '34613665384';
const WHATSAPP_MSG = encodeURIComponent(
  'Hola M2HAUS, me gustaría solicitar información sobre sus servicios eléctricos en Madrid.'
);

export const PHONE_LINK = `tel:${PHONE_NUMBER}`;
export const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MSG}`;
