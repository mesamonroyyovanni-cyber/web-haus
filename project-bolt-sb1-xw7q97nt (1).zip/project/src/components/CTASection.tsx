import { MessageCircle } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';
import { WHATSAPP_LINK } from '@/lib/contact';

const BG_IMAGE =
  'https://images.pexels.com/photos/7598374/pexels-photo-7598374.jpeg?auto=compress&cs=tinysrgb&w=1920';

export default function CTASection() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section id="contacto" className="relative py-28 lg:py-36 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src={BG_IMAGE}
          alt="Arquitectura residencial moderna para proyectos M2HAUS Madrid"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-bronze-dark/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <div
          ref={ref}
          className={`reveal ${visible ? 'is-visible' : ''}`}
        >
          <span className="inline-block text-bronze-light font-bold text-sm tracking-widest uppercase mb-6">
            Consulta Técnica
          </span>
          <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-white leading-tight text-balance text-shadow-lg">
            Tu proyecto en Madrid en manos de M2HAUS.
            <span className="block mt-2 text-white/90">Sin sorpresas, con rigor y garantía.</span>
          </h2>
          <p className="mt-8 text-lg text-white/70 max-w-2xl mx-auto leading-relaxed">
            Solicite una consulta técnica personalizada. Evaluamos su proyecto, le
            asesoramos con honestidad y le entregamos un presupuesto claro y cerrado.
          </p>

          {/* CTA Button */}
          <div className="mt-12 flex justify-center">
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-3 px-10 py-5 rounded-xl bg-bronze text-white font-bold text-lg hover:bg-bronze-dark transition-all duration-300 hover:shadow-2xl hover:shadow-bronze/50 hover:scale-[1.03] border border-bronze-light/40"
            >
              <MessageCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
              Solicitar Consulta Técnica por WhatsApp
            </a>
          </div>

          {/* Secondary info */}
          <div className="mt-10 flex flex-wrap justify-center items-center gap-x-8 gap-y-3 text-white/50 text-sm">
            <span>Respuesta en menos de 24 horas</span>
            <span className="hidden sm:inline w-1 h-1 rounded-full bg-white/30" />
            <span>Presupuesto sin compromiso</span>
            <span className="hidden sm:inline w-1 h-1 rounded-full bg-white/30" />
            <span>Toda la Comunidad de Madrid</span>
          </div>
        </div>
      </div>
    </section>
  );
}
