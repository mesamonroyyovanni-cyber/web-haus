import { Phone, MessageCircle, ChevronDown } from 'lucide-react';
import { PHONE_LINK, WHATSAPP_LINK } from '@/lib/contact';

const HERO_IMAGE =
  'https://images.pexels.com/photos/8134849/pexels-photo-8134849.jpeg?auto=compress&cs=tinysrgb&w=1920';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <img
          src={HERO_IMAGE}
          alt="Casa moderna de lujo con piscina — M2HAUS domótica Madrid"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 hero-gradient" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 w-full pt-24 pb-20">
        <div className="max-w-3xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-8 animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-bronze animate-pulse-slow" />
            <span className="text-white/90 text-sm font-semibold tracking-wide">
              Electricista Autorizado · Comunidad de Madrid
            </span>
          </div>

          {/* H1 */}
          <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white leading-[1.1] text-balance text-shadow-lg animate-fade-in-up">
            M2HAUS
            <span className="block mt-3 text-2xl sm:text-3xl lg:text-4xl font-bold text-white/95">
              Electricidad y Domótica Avanzada en Madrid
            </span>
          </h1>

          {/* Subtitle */}
          <p className="mt-6 text-lg sm:text-xl text-white/85 leading-relaxed max-w-2xl animate-fade-in-up [animation-delay:0.2s] opacity-0">
            Ingeniería eléctrica y acabados de precisión para viviendas exclusivas y
            espacios comerciales. Seguridad, normativa y estética impecable.
          </p>

          {/* CTAs */}
          <div className="mt-10 flex flex-col sm:flex-row gap-4 animate-fade-in-up [animation-delay:0.4s] opacity-0">
            <a
              href={PHONE_LINK}
              className="group flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-white text-black font-bold text-base hover:bg-metallic transition-all duration-300 hover:shadow-2xl hover:scale-[1.02]"
            >
              <Phone className="w-5 h-5 text-bronze group-hover:scale-110 transition-transform" />
              Llamar Ahora 24H
            </a>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-bronze text-white font-bold text-base hover:bg-bronze-dark transition-all duration-300 hover:shadow-2xl hover:shadow-bronze/40 hover:scale-[1.02] border border-bronze-light/30"
            >
              <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Contactar por WhatsApp
            </a>
          </div>

          {/* Trust indicators */}
          <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-3 animate-fade-in [animation-delay:0.6s] opacity-0">
            {[
              'Certificación y Garantía Oficial',
              'Experiencia en Retail',
              'Cumplimiento de Plazos',
            ].map((item) => (
              <div key={item} className="flex items-center gap-2 text-white/75 text-sm font-medium">
                <span className="w-1.5 h-1.5 rounded-full bg-bronze-light" />
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll hint */}
      <a href="#diferencia" className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 hidden md:flex flex-col items-center gap-2">
        <span className="text-white/50 text-xs font-semibold tracking-widest uppercase">Descubrir</span>
        <ChevronDown className="w-5 h-5 text-white/50 animate-scroll-hint" />
      </a>
    </section>
  );
}
