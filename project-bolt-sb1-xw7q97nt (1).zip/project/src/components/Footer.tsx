import { Phone, MessageCircle, MapPin, Mail } from 'lucide-react';
import { PHONE_LINK, WHATSAPP_LINK } from '@/lib/contact';

export default function Footer() {
  return (
    <footer className="bg-anthracite text-white/60">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-5">
              <img
                src="/images/WhatsApp_Image_2026-08-26_at_11.39.56_PM.jpeg"
                alt="M2HAUS"
                className="w-[104px] h-14 rounded-md object-cover object-center"
              />
            </div>
            <p className="text-sm leading-relaxed max-w-xs">
              Electricista Madrid M2HAUS. Especialistas en instalaciones eléctricas,
              cuadros eléctricos Madrid, instalaciones eléctricas integrales Madrid y
              domótica. Máxima pulcritud, normativa y plazos.
            </p>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-heading font-bold text-white text-sm tracking-widest uppercase mb-5">
              Servicios
            </h3>
            <ul className="space-y-3 text-sm">
              <li><a href="#servicios" className="hover:text-white transition-colors">Instalaciones Eléctricas Integrales</a></li>
              <li><a href="#servicios" className="hover:text-white transition-colors">Cuadros Eléctricos de Alta Precisión</a></li>
              <li><a href="#servicios" className="hover:text-white transition-colors">Domótica y Eficiencia Energética</a></li>
              <li><a href="#servicios" className="hover:text-white transition-colors">Soluciones para Locales Comerciales</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-heading font-bold text-white text-sm tracking-widest uppercase mb-5">
              Contacto
            </h3>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-bronze-light mt-0.5 shrink-0" />
                <span>Toda la Comunidad de Madrid</span>
              </li>
              <li>
                <a
                  href={PHONE_LINK}
                  className="flex items-center gap-3 hover:text-white transition-colors"
                >
                  <Phone className="w-4 h-4 text-bronze-light shrink-0" />
                  613 665 384
                </a>
              </li>
              <li>
                <a
                  href={WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 hover:text-white transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-bronze-light shrink-0" />
                  WhatsApp · 613 665 384
                </a>
              </li>
              <li className="flex items-start gap-3">
                <a href="mailto:info@m2haus.es" className="flex items-start gap-3 hover:text-white transition-colors">
                  <Mail className="w-4 h-4 text-bronze-light mt-0.5 shrink-0" />
                  <span>info@m2haus.es</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-14 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-white/40">
          <p>© {new Date().getFullYear()} M2HAUS · Electricista autorizado en Madrid</p>
          <p className="flex items-center gap-2">
            <span>Instalador domótica Madrid</span>
            <span className="w-1 h-1 rounded-full bg-white/20" />
            <span>Cuadros eléctricos Madrid</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
