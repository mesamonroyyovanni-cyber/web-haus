import { MessageCircle } from 'lucide-react';
import { WHATSAPP_LINK } from '@/lib/contact';

export default function FloatingWhatsApp() {
  return (
    <a
      href={WHATSAPP_LINK}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Contactar por WhatsApp"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-bronze text-white flex items-center justify-center shadow-2xl shadow-bronze/40 hover:bg-bronze-dark hover:scale-110 transition-all duration-300 group"
    >
      <MessageCircle className="w-7 h-7 group-hover:scale-110 transition-transform" />
      <span className="absolute inset-0 rounded-full bg-bronze animate-ping opacity-20 group-hover:opacity-0 transition-opacity" />
    </a>
  );
}
