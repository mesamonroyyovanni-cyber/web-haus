import { ShoppingBag, ShieldCheck, Clock } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';

const DIFFERENTIATORS = [
  {
    icon: ShoppingBag,
    title: 'Experiencia en Retail y Centros Comerciales',
    description:
      'Proyectos comerciales de alto nivel, incluyendo locales en centros comerciales como Goconut en San Sebastián de los Reyes. Conocemos los estándares más exigentes de los grandes operadores: protocolos de seguridad, plazos de entrega ajustados y coordinación con la dirección de obra del centro.',
  },
  {
    icon: ShieldCheck,
    title: 'Certificación y Garantía Oficial',
    description:
      'Electricista autorizado con todas las certificaciones vigentes. Cada instalación cuenta con garantía oficial, boletín eléctrico y documentación técnica completa, entregada al cliente para garantizar la trazabilidad y el cumplimiento normativo.',
  },
  {
    icon: Clock,
    title: 'Estricto Cumplimiento de Plazos',
    description:
      'Planificación rigurosa y compromiso real con los tiempos de entrega. Su local o vivienda operativa cuando la necesita, sin excusas ni retrasos. Coordinación proactiva con todos los gremios de la obra para que la electricidad nunca sea el cuello de botella.',
  },
];

export default function Differentiators() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section id="diferencia" className="py-24 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <div
          ref={ref}
          className={`reveal ${visible ? 'is-visible' : ''} max-w-3xl mb-16`}
        >
          <span className="inline-block text-bronze font-bold text-sm tracking-widest uppercase mb-4">
            Por qué M2HAUS
          </span>
          <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-black leading-tight text-balance">
            Ingeniería eléctrica ejecutada con rigor y precisión.
          </h2>
          <p className="mt-6 text-lg text-anthracite/70 leading-relaxed">
            En M2HAUS elevamos el estándar de la instalación eléctrica en Madrid con rigor
            técnico, diseño y acabados de precisión. Cada proyecto se ejecuta con máxima
            pulcritud, cumplimiento de normativas y atención al detalle que su vivienda o
            local merece.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {DIFFERENTIATORS.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className={`reveal ${visible ? 'is-visible' : ''} group relative p-8 rounded-2xl bg-gray-50 border border-gray-100 hover:border-bronze/20 hover:shadow-xl hover:shadow-bronze/5 transition-all duration-500`}
                style={{ transitionDelay: `${idx * 120}ms` }}
              >
                {/* Icon */}
                <div className="w-14 h-14 rounded-xl bg-bronze/10 flex items-center justify-center mb-6 group-hover:bg-bronze transition-colors duration-500">
                  <Icon className="w-7 h-7 text-bronze group-hover:text-white transition-colors duration-500" />
                </div>
                <h3 className="font-heading font-bold text-xl text-black mb-3 leading-snug">
                  {item.title}
                </h3>
                <p className="text-anthracite/65 leading-relaxed text-[15px]">
                  {item.description}
                </p>

                {/* Accent line */}
                <div className="absolute bottom-0 left-8 right-8 h-0.5 bg-bronze/0 group-hover:bg-bronze/30 transition-all duration-500" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
