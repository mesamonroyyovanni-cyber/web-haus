import { Home, Cpu, Zap, Store, ArrowRight } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';
import { WHATSAPP_LINK } from '@/lib/contact';

const SERVICES = [
  {
    icon: Home,
    title: 'Instalaciones Eléctricas Integrales',
    description:
      'Renovación completa de instalaciones eléctricas en viviendas y locales de Madrid. Proyecto llave en mano: diseño, ejecución y certificación, con acabados de precisión.',
    features: [
      'Diseño y cálculo de la instalación adaptado a su vivienda o local',
      'Sustitución de cableado antiguo y modernización completa del sistema',
      'Certificación oficial y documentación técnica entregada al cliente',
      'Coordinación con otros gremios de obra para una ejecución sin fricciones',
    ],
    image:
      'https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg?auto=compress&cs=tinysrgb&w=800',
    keyword: 'instalaciones eléctricas integrales Madrid',
  },
  {
    icon: Zap,
    title: 'Cuadros Eléctricos de Alta Precisión',
    description:
      'Reacondicionamiento y balance de cargas en cuadros eléctricos Madrid. Organización profesional con peines de cobre, etiquetado y distribución equilibrada para máxima seguridad.',
    features: [
      'Reacondicionamiento completo con peines de cobre y cableado ordenado',
      'Balance de cargas por fases para evitar disparos y sobrecargas',
      'Instalación de diferenciales y magnetotérmicos de gama alta',
      'Etiquetado profesional de cada circuito para mantenimiento futuro',
    ],
    image:
      'https://images.pexels.com/photos/28942196/pexels-photo-28942196.jpeg?auto=compress&cs=tinysrgb&w=800',
    keyword: 'cuadros eléctricos Madrid',
  },
  {
    icon: Cpu,
    title: 'Domótica y Eficiencia Energética',
    description:
      'Casas inteligentes con control total: iluminación, climatización, seguridad y energía. Como instalador domótica Madrid integramos sistemas KNX y plataformas líderes del mercado.',
    features: [
      'Integración de sistemas KNX y plataformas domóticas líderes',
      'Control de iluminación, climatización, persianas y escenas personalizadas',
      'Gestión energética con monitorización de consumo en tiempo real',
      'Integración con seguridad: cámaras, accesos y detección de presencia',
    ],
    image:
      'https://images.pexels.com/photos/8134849/pexels-photo-8134849.jpeg?auto=compress&cs=tinysrgb&w=800',
    keyword: 'instalador domótica Madrid',
  },
  {
    icon: Store,
    title: 'Soluciones para Locales Comerciales',
    description:
      'Electricidad para retail de alta gama: iluminación escénica, cuadros de distribución, sistemas de seguridad y cumplimiento normativo. Experiencia en centros comerciales.',
    features: [
      'Iluminación escénica y de escaparate adaptada a la imagen de marca',
      'Cuadros de distribución dimensionados para cargas comerciales reales',
      'Cumplimiento normativo de locales de pública concurrencia',
      'Experiencia en centros comerciales, incluyendo el proyecto Goconut',
    ],
    image:
      'https://images.pexels.com/photos/13068364/pexels-photo-13068364.jpeg?auto=compress&cs=tinysrgb&w=800',
    keyword: 'electricista Madrid M2HAUS',
  },
];

export default function Services() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section id="servicios" className="py-24 lg:py-32 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        {/* Section header */}
        <div
          ref={ref}
          className={`reveal ${visible ? 'is-visible' : ''} max-w-3xl mb-16`}
        >
          <span className="inline-block text-bronze font-bold text-sm tracking-widest uppercase mb-4">
            Servicios
          </span>
          <h2 className="font-heading font-extrabold text-3xl sm:text-4xl lg:text-5xl text-black leading-tight text-balance">
            Ingeniería eléctrica de máximo nivel
          </h2>
          <p className="mt-6 text-lg text-anthracite/70 leading-relaxed">
            Desde la instalación integral de una vivienda exclusiva hasta la
            integración tecnológica de un local comercial. M2HAUS cubre cada
            necesidad eléctrica con el mismo estándar de excelencia, seguridad y
            cumplimiento normativo en toda la Comunidad de Madrid.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {SERVICES.map((service, idx) => {
            const Icon = service.icon;
            return (
              <div
                key={service.title}
                className={`reveal ${visible ? 'is-visible' : ''} group relative overflow-hidden rounded-2xl bg-white border border-gray-100 hover:shadow-2xl hover:shadow-black/5 transition-all duration-500`}
                style={{ transitionDelay: `${idx * 120}ms` }}
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={service.image}
                    alt={`${service.title} — M2HAUS Madrid`}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                  {/* Icon overlay */}
                  <div className="absolute top-4 left-4 w-12 h-12 rounded-xl bg-white/90 backdrop-blur-md flex items-center justify-center shadow-lg">
                    <Icon className="w-6 h-6 text-bronze" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <h3 className="font-heading font-bold text-xl text-black mb-3 leading-snug">
                    {service.title}
                  </h3>
                  <p className="text-anthracite/65 leading-relaxed text-[15px] mb-5">
                    {service.description}
                  </p>
                  <ul className="space-y-2.5 mb-6">
                    {service.features.map((feature) => (
                      <li
                        key={feature}
                        className="flex items-start gap-2.5 text-sm text-anthracite/70"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-bronze mt-1.5 shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <a
                    href={WHATSAPP_LINK}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm font-semibold text-bronze hover:text-bronze-dark transition-colors group/link"
                  >
                    Solicitar información
                    <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                  </a>
                  <span className="sr-only">{service.keyword}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
